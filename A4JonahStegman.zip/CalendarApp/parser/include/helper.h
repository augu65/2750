/*
 * Helper functions for calendarparser.c
 *Jonah Stegmna
 *0969112
 */
#ifndef HELPER_H
#define HELPER_H
#include <ctype.h>
#include "CalendarParser.h"

//creates a event struct and inserts data into it
Event * createEvent(char** lines,int position, int size);

//creates a alarm struct and inserts data into it
Alarm * createAlarm(char** lines,int position,int size);

//creates a property struct and inserts data into it
Property * createProperty(char* line);

//creates a dattiem struct and inserts data into it
DateTime * createDate(char* line);

char * writeCal(const Calendar* obj);
char * writeEvent(Event *obj);
char * writeAlarm(Alarm * obj);
char * writeProperty(Property * obj);
char * validateToJSON(char*file);
char * alarmwrapper(char* file ,int event);
char * propwrapper(char*file,int event);
char * eventwrapper(char*file);
char * createeventwrapper(char*file, char*id,char*dtstart,char*dtstamp,char*summary);
#endif
