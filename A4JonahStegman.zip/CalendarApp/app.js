'use strict'

// C library API
const ffi = require('ffi');

// Express App (Routes)
const express = require("express");
const app     = express();
const path    = require("path");
const fileUpload = require('express-fileupload');
app.use(fileUpload());

const mysql=require('mysql'); 

// Minimization
const fs = require('fs');
const JavaScriptObfuscator = require('javascript-obfuscator');
let  con={};
// Important, pass in port as in `npm run dev 1234`, do not change
const portNum = process.argv[2];
let sharedLib=ffi.Library('./libcal',{
	'validateToJSON':['string',['string']],
	'eventwrapper':['string',['string']],
	'alarmwrapper':['string',['string','int']],
	'propwrapper':['string',['string','int']],
	'createeventwrapper':['string',['string','string','string','string','string']],
	'createcalwrapper':['string',['string','string','string','string','string','string','string']]
});

// Send HTML at root, do not change
app.get('/',function(req,res){
  res.sendFile(path.join(__dirname+'/public/index.html'));
});

// Send Style, do not change
app.get('/style.css',function(req,res){
  //Feel free to change the contents of style.css to prettify your Web app
  res.sendFile(path.join(__dirname+'/public/style.css'));
});

// Send obfuscated JS, do not change
app.get('/index.js',function(req,res){
  fs.readFile(path.join(__dirname+'/public/index.js'), 'utf8', function(err, contents) {
    const minimizedContents = JavaScriptObfuscator.obfuscate(contents, {compact: true, controlFlowFlattening: true});
    res.contentType('application/javascript');
    res.send(minimizedContents._obfuscatedCode);
  });
});

//Respond to POST requests that upload files to uploads/ directory
app.post('/upload', function(req, res) {
  if(!req.files) { 
     return res.status(400).send('No files were uploaded.');
  }
  let uploadFile = req.files.uploadFile;
//  let valid=sharedLib.validateToJSON(uploadFile.name);
  // Use the mv() method to place the file somewhere on your server
  uploadFile.mv('uploads/' + uploadFile.name, function(err) {
    if(err) {
      return res.status(500).send(err);
    }
  var resp=sharedLib.validateToJSON('uploads/'+uploadFile.name);
 console.log(resp);
  if(resp[0]!='{'){
      fs.unlinkSync('uploads/'+uploadFile.name);
  }
    res.redirect('/');
  });
   //return "works";
});
//Respond to GET requests for files in the uploads/ directory
app.get('/uploads/:name', function(req , res){
  fs.stat('uploads/' + req.params.name, function(err, stat) {
    console.log(err);
    if(err == null) {
      res.sendFile(path.join(__dirname+'/uploads/' + req.params.name));
    } else {
      res.send('');
    }
  });
});

//******************** Your code goes here ******************** 

//Sample endpoint
app.get('/filenames', function(req , res){
  let filearr1=[];
  fs.readdirSync('./uploads').forEach(file=>{
     filearr1.push(file);
  });
  var i=0;
  let filearr=[];
  for(i=0; i<filearr1.length; i++){
	var response=sharedLib.validateToJSON('uploads/'+filearr1[i]);
	if(response[0]=='{'){
	   filearr.push(filearr1[i]+response);
	}
	
  }
	console.log(filearr);
  res.send({
    filearr
  });
});
app.get('/createCal', function(req , res){
  var prodid=req.query.id;
  var version=req.query.version;
  var userid=req.query.userId;
  var start=req.query.dtstart;
  var create=req.query.dtstamp;
  var summary=req.query.summary;
  var response=sharedLib.createcalwrapper('uploads/'+req.query.filename,prodid,version,userid,start,create,summary);
  res.send({
    response
  });
//res.redirect('/');
	
});
app.get('/createEvents', function(req , res){
	
  var id=req.query.id;
  var dtstart=req.query.dtstart;
  var dtstamp=req.query.dtstamp;
  var sum=req.query.summary;
  var response=sharedLib.createeventwrapper('uploads/'+req.query.filename,id,dtstart,dtstamp,sum);
  res.send({
  response
  });
// res.redirect('/');
});
app.get('/events', function(req , res){
  var response=sharedLib.eventwrapper('uploads/'+req.query.file);
  res.send({
    response
  });
});
app.get('/alarm',function(req, res){
  
 var response=sharedLib.alarmwrapper('uploads/'+req.query.file, req.query.id);
  console.log(response);
	res.send({
	  response
 });
});

app.get('/property',function(req, res){
  
 var response=sharedLib.propwrapper('uploads/'+req.query.file, req.query.id);
 res.send({
	  response
 });
});

app.get('/login',function(req, res){
  con=mysql.createConnection({
  host:"dursley.socs.uoguelph.ca",
  database:req.query.database,
  user:req.query.username,
  password:req.query.password
})
con.connect(function(err){
 if (err) {
  res.send({response:"error"});
 }

});
con.query("create table if not exists FILE(cal_id int auto_increment, file_Name VARCHAR(60) NOT NULL, version int NOT NULL, prod_id VARCHAR(256) NOT NULL, primary key(cal_id))",function(err,rows,fields){});
con.query("create table if not exists EVENT(event_id int auto_increment, summary VARCHAR(1024), start_time DATETIME NOT NULL, location  VARCHAR(60), organizer VARCHAR(256), cal_file INT NOT NULL,  primary key(event_id), FOREIGN KEY(cal_file) REFERENCES FILE(cal_id) ON DELETE CASCADE )",function(err,rows,fields){});
con.query("create table if not exists ALARM(alarm_id int auto_increment, action VARCHAR(256) NOT NULL, `trigger` VARCHAR(256) NOT NULL, event INT NOT NULL, primary key(alarm_id), FOREIGN KEY(event) REFERENCES EVENT(event_id) ON DELETE CASCADE)",function(err,rows,fields){});
 res.send({response:"connected"});
});

app.get('/addqueryfile',function(req,res){
con.query("select* from FILE where file_Name ='"+req.query.file+"'",function(err,rows,field){
if(rows.length==0){
con.query(req.query.string,function(err,rows,fields){
 if(err){
 res.send({response:"error"});
 }else{
 con.query("select cal_id from FILE where file_Name='"+req.query.file+"'",function(err,rows,fields){
 res.send({response:"success",
 	position:rows});
 });

 }});
 }else{
 res.send({response:req.query.file,
 	   position:"-1"});
}
 
 });

});
app.get('/addqueryevent',function(req,res){
	con.query(req.query.string,function(err,rows,fields){
	res.send({row:rows});
	});
});
app.get('/addqueryalarm',function(req,res){
	con.query(req.query.string,function(err,rows,fields){
	res.send({});
	});
});

app.get('/deleteData',function(req,res){
con.query("DELETE FROM FILE");
res.send({});
});
app.get('/displaydata',function(req,res){
con.query("SELECT table_name, table_rows from INFORMATION_SCHEMA.TABLES where TABLE_SCHEMA=DATABASE()",function(err,rows,fields){
res.send({response:rows});
});
});
app.get('/displayeventdata',function(req,res){
con.query("select * from EVENT",function(err,rows,fields){
res.send({response:rows});
});
});
app.get('/displayeventalarmdata',function(req,res){
con.query("select * from EVENT where exists(select event from ALARM where ALARM.event = EVENT.event_id)",function(err,rows,fields){
res.send({response:rows});
});
});
app.get('/displayfileeventdata',function(req,res){
	console.log(req.query.file);
con.query("select a.* from EVENT a join (select file_Name,cal_id from FILE)b where a.cal_file=b.cal_id and b.file_Name='"+req.query.file+"'",function(err,rows,fields){
	console.log(rows);
	res.send({response:rows});
});
});
app.get('/displayconflicteventdata',function(req,res){
con.query("select a.* from EVENT a JOIN (SELECT start_time,COUNT(*) from EVENT group by start_time having count(*)>1) b on a.start_time=b.start_time",function(err,rows,fields){
res.send({response:rows});
});
});
app.get('/displayalarmObidata',function(req,res){
con.query("select a.* from ALARM a JOIN (SELECT location,event_id from EVENT)b where location='house' and a.event=b.event_id",function(err,rows,fields){
res.send({response:rows});
});
});


app.get('/displayfilealarmdata',function(req,res){
con.query("select a.* from FILE a JOIN (select cal_file,COUNT(*) from EVENT group by cal_file having count(*)>1)b on a.cal_id=b.cal_file where exists(select cal_file from EVENT where exists(select event from ALARM where ALARM.event =EVENT.event_id) and EVENT.cal_file=a.cal_id)",function(err,rows,fields){
res.send({response:rows});
});
});
app.listen(portNum);
console.log('Running app at localhost: ' + portNum);
