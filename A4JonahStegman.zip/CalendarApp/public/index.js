




// Put all onload AJAX calls here, and event listeners
$(document).ready(function() {
    // On page-load AJAX Example
    $.ajax({
        type: 'get',            //Request type
        dataType: 'json',       //Data type - we will use JSON for almost everything 
        url: '/filenames',   //The server endpoint we are connecting to
        success: function (data) {
          //   console.log(data
	     var statusstuff=sessionStorage.getItem('status');
	     document.getElementById('status').innerHTML=statusstuff;
	     var i=0; 
	     var table=document.getElementById("fileTable");
	     for(i=0; i<data.filearr.length; i++){
	       var file=data.filearr[i].split('{');
	       var rest=data.filearr[i].split(':');
	       var row=table.insertRow(table.rows.length);
	       var name=row.insertCell(0);
	       var version=row.insertCell(1);
	       var prod=row.insertCell(2);
	       var evt=row.insertCell(3);
	       var prop=row.insertCell(4);
		name.innerHTML="<a href='/uploads/"+file[0]+"'>"+file[0]+"</a>";
		version.innerHTML=rest[1].split(',')[0];
		prod.innerHTML=rest[2].split('"')[1];
		prop.innerHTML=rest[3].split(',')[0];
		evt.innerHTML=rest[4].split('}')[0];
	     }
	
	     if(i==0){
	       var row=table.insertRow(table.rows.length);
	       var name=row.insertCell(0);
	       name.innerHTML="No Files Found";	   
	     }else{
	      if(sessionStorage.getItem('database')=="connected"){
	      document.getElementById("storeAll").style.visibility="visible";
	   	document.getElementById("clearAll").style.visibility="visible";
 		 document.getElementById("displayAll").style.visibility="visible";
		document.getElementById("query1").style.visibility="visible";
document.getElementById("query2d").style.visibility="visible";
document.getElementById("query3").style.visibility="visible";
document.getElementById("query4").style.visibility="visible";
document.getElementById("query5").style.visibility="visible";
document.getElementById("query6").style.visibility="visible";

	      }
	     }

	},

        fail: function(error) {
            // Non-200 return, do something with error
            console.log(error); 
        }
    });
    $("#submitCal").click(function(){
	$.ajax({
	  type:'post',
	  dataType:'json',
	  url:'/upload',
	  success:function(data){
		 console.log(data);
	var previous=document.getElementById("status").innerHTML;
	 document.getElementById("status").innerHTML="Uploaded file to server</br>"+previous;
	 sessionStorage.setItem("status",document.getElementById('status').innerHTML);
	},
	fail: function(error){
		console.log(error);
	var previous=document.getElementById("status").innerHTML;
	 document.getElementById("status").innerHTML="Invalid File</br>"+previous;
	 sessionStorage.setItem("status",document.getElementById('status').innerHTML);
	}
	});
	
});
   
  
$('#clear').click(function(){
document.getElementById("status").innerHTML="";
sessionStorage.setItem("status",document.getElementById('status').innerHTML);

});
$("#CAlarms").click(function(){
	var alarm=document.getElementById('ddwnA');
	    if(alarm.style.visibility=='visible'){
	    alarm.style.visibility='hidden';
	    }else{
	    alarm.style.visibility='visible';
	    }
    });
    $("#SEOP").click(function(){
       var prop=document.getElementById('ddwnP');
	    if(prop.style.visibility=='visible'){
            prop.style.visibility='hidden';
	    }
	    else{
	    prop.style.visibility='visible';
	    }
    });


/*
$('#submitCal').click(function(){
var file=$('#uploadFile')[0].files[0].name;
var previous=document.getElementById("status").innerHTML;   
document.getElementById("status").innerHTML="Uploaded file "+file+" to server</br>"+previous;
 sessionStorage.setItem("status",document.getElementById('status').innerHTML);
 //document.getElementById("uploadFileCal").reset();
document.location.reload();
/*$.ajax({
        type: 'get',            //Request type
        dataType: 'json',       //Data type - we will use JSON for almost everything 
        url: '/filenames',   //The server endpoint we are connecting to
        success: function (data) {
            console.log(data);
	var previous=document.getElementById("status").innerHTML;   
	var j=0;
	  for(i=0; i<data.filearr.length; i++){
		 if(data.filearr[i].split('{')[0]==file){
			j=1;
		//	 break;
		}
	  }
	if(j==1){
	document.getElementById("status").innerHTML="Uploaded file to server</br>"+previous;
	}else{
	document.getElementById("status").innerHTML="Failed to uploaded file to server</br>"+previous;
	}
	 sessionStorage.setItem("status",document.getElementById('status').innerHTML);
        document.getElementById("uploadFileCal").reset();
        document.location.reload();
	}, fail:function(error){
		console.log(error);
	}
});
});*//*
});*/
});

function alarmjson(filename,num){
 $.ajax({
  type:'get',
  dataType:'json',
  url:'/alarm',
  data:{
	  file:filename,
	  id:num
   },
   success:function(data){
   var previous=document.getElementById("status").innerHTML;
   var newstuff="<b>Alarms for Event No:"+num+" in calendar:"+filename+"</b></br>";
   var i=0;
   var j=0;
   var alarms=JSON.parse(data.response);
   for(i=0; i<alarms.length; i++){
	   j=i+1;
   newstuff=newstuff+"<b>alarm No:"+j+"</b>";
   newstuff=newstuff+"</br>Trigger :"+alarms[i].Trigger;
   newstuff=newstuff+"</br>Action Type:"+alarms[i].Action;
   newstuff=newstuff+"</br> Number of Properties:"+alarms[i].numProps;
newstuff=newstuff+"</br>";

   }
   if(alarms.length==1){
   document.getElementById("status").innerHTML="<b>No </b>"+newstuff+" </br>"+previous;
   }else{
   document.getElementById("status").innerHTML=newstuff+" </br>"+previous;
   }
   },
    fail:function(error){
    console.log(error);}
 });

}

function propjson(filename,num){
 $.ajax({
  type:'get',
  dataType:'json',
  url:'/property',
  data:{
	  file:filename,
	  id:num
   },
   success:function(data){
   var previous=document.getElementById("status").innerHTML;
   var newstuff="<b>Optional Properties for Event No:"+num+" in calendar:"+filename+"</b></br>";
   var i=0;
   var j=0;
   var prop=data.response.split("}");
   for(i=0; i<prop.length-1; i++){
	   j=i+1;
   newstuff=newstuff+"<b>Property No:"+j+"</b>";
   newstuff=newstuff+"</br>Property Name:"+prop[i].split(':')[1].split('"')[1];
   newstuff=newstuff+"</br>Property Description:"+prop[i].split(':')[2].split('"')[1]+"</br>";

   }
   if(prop.length==1){
   document.getElementById("status").innerHTML="<b>No </b>"+newstuff+"</br>"+previous;
   }else{
   document.getElementById("status").innerHTML=newstuff+"</br>"+previous;
   }
   },
    fail:function(error){
    console.log(error);}
 });

}
function createEvent(filename){
 sessionStorage.setItem("Event",filename);
}
function eventjson (filename){
  $("#event").empty();
    var table=document.getElementById("event");
    var row=table.insertRow(table.rows.length);
    var id=row.insertCell(0);
    var start=row.insertCell(1);
    var date=row.insertCell(2);
    var sumary=row.insertCell(3);
    var prop=row.insertCell(4);
    var alarm=row.insertCell(5);
    id.innerHTML='Event</br>No';
    start.innerHTML='Start date';
    date.innerHTML='Start time';
    sumary.innerHTML="Summary";
    prop.innerHTML='Prop';
    alarm.innerHTML='Alarm';
 $.ajax({
  type:'get',
  dataType:'json',
  url:'/events',
  data:{
	  file:filename
   },
   success: function(data){
	     var i=0;
	     var table=document.getElementById("event");
	     var events=data.response.split("}");
	   var j=0;
	   $("#showAlarm").empty();
	   $("#showProperty").empty();
	   for(i=0; i<events.length-1; i++){
	(function(){
	  var newdrop=document.createElement("option");
	  newdrop.innerHTML=j+1;
	  newdrop.setAttribute('id','dropdowna');
	  newdrop.setAttribute('value',	j+1);
	  newdrop.addEventListener('click',function(){alarmjson(filename,newdrop.value);},false);
	  document.getElementById("showAlarm").appendChild(newdrop);
	 var newdropProp=document.createElement("option");
	  newdropProp.innerHTML=j+1;
	  newdropProp.setAttribute('id','dropdownp');
	  newdropProp.setAttribute('value',	j+1);
	  newdropProp.addEventListener('click',function(){propjson(filename,newdropProp.value);},false);
	  document.getElementById("showProperty").appendChild(newdropProp);
       
	     
	       var row=table.insertRow(table.rows.length);
	       var id=row.insertCell(0);
	       var start=row.insertCell(1);
	       var date=row.insertCell(2);
	       var sumary=row.insertCell(3);
	       var prop=row.insertCell(4);
	       var alarm=row.insertCell(5);
	       id.innerHTML=j+1;
	       start.innerHTML=events[i].split(":")[2].split('"')[1].slice(0,4)+'/';
	       start.innerHTML=start.innerHTML+events[i].split(':')[2].split('"')[1].slice(4,6)+'/';
	       start.innerHTML=start.innerHTML+events[i].split(':')[2].split('"')[1].slice(6,8);
	       date.innerHTML=events[i].split(':')[3].split('"')[1].slice(0,2)+':';
	       date.innerHTML=date.innerHTML+events[i].split(':')[3].split('"')[1].slice(2,4)+':';
	       date.innerHTML=date.innerHTML+events[i].split(':')[3].split('"')[1].slice(4,6);
	       if("isUTC"==events[i].split(':')[3].split(',')[1].split('"')[1]){
			date.innerHTML=date.innerHTML+" (isUTC)";
	       }
	       prop.innerHTML=events[i+1].split(":")[1].split(',')[0];
	       alarm.innerHTML=events[i+1].split(":")[2].split(',')[0];
	       sumary.innerHTML=events[i+1].split('"')[7];
		i=i+1;
	     	j=j+1;
		}());
	   }
	     if(i==0){
	       var row=table.insertRow(table.rows.length);
	       var name=row.insertCell(0);
	       name.innerHTML="No Files Found";	   
	     }

   },
   fail:function(error){
   }
	});
}

function function1(){
   var file=sessionStorage.getItem("Event");
   sessionStorage.removeItem("Event");
   var userID=document.forms["createEvt"]["usrIDE"].value;
   var dtstart=document.forms["createEvt"]["dtstart"].value;
   var dtstamp=document.forms["createEvt"]["dtstamp"].value;
   var summary=document.forms["createEvt"]["summary"].value;
   var idR=/[^\s]{1,1000}$/;
   var dtsR=/^[1-9]{1}\d{7}[T]\d{6}[Z]?$/;
   var userResp=idR.test(userID);
   var dtstartResp=dtsR.test(dtstart);
   var dtstampResp=dtsR.test(dtstamp);
   var overall=true;
   if(file===""||file==null){
	   overall=false;
	    var previous=document.getElementById("status").innerHTML;
	    document.getElementById("status").innerHTML="No Calendar selected when creating Event</br>"+previous;
	    sessionStorage.setItem("status",document.getElementById('status').innerHTML);

  }
  if(userResp!=true){
	   overall=false;
	    var previous=document.getElementById("status").innerHTML;
	    document.getElementById("status").innerHTML="Invalid UserID when creating Event</br>"+previous;
	    sessionStorage.setItem("status",document.getElementById('status').innerHTML);

	 }
	 if(summary===""){
           overall=false;
	    var previous=document.getElementById("status").innerHTML;
	    document.getElementById("status").innerHTML="Invalid Summary when creating Event</br>"+previous;
	    sessionStorage.setItem("status",document.getElementById('status').innerHTML);

	 }
	 if(dtstartResp!=true){
	   overall=false;
	    var previous=document.getElementById("status").innerHTML;
	    document.getElementById("status").innerHTML="Invalid Start Time when creating Event</br>"+previous;
	    sessionStorage.setItem("status",document.getElementById('status').innerHTML);

	 } 
	if(dtstampResp!=true){
	  overall=false;
	    var previous=document.getElementById("status").innerHTML;
	    document.getElementById("status").innerHTML="Invalid Creation Time when creating Event</br>"+previous;
	    sessionStorage.setItem("status",document.getElementById('status').innerHTML);
	}
 if(overall==true){
   var obj={
       "filename":file,
       "id":userID,
       "dtstart":dtstart,
       "dtstamp":dtstamp,
       "summary":summary
   };
}else{
	obj={};
}
  var str=JSON.stringify(obj);

  if(str!=""){
	$.ajax({
	 type:'get',
	 dataType:'json',
	url:'/createEvents',
	data:obj,
	 success: function(data){
	  if(data.response=="Success"){
	  var previous=document.getElementById("status").innerHTML;
	  document.getElementById("status").innerHTML="Created a new Event in calendar "+file+".</br>"+previous;
	  sessionStorage.setItem("status",document.getElementById('status').innerHTML);
	 	document.getElementById('createEvt').reset();
		  document.location.reload();
	  }else{
		var previous=document.getElementById("status").innerHTML;
 	document.getElementById("status").innerHTML="Error Creating new event in calendar "+file+".</br>"+previous;
	 sessionStorage.setItem("status",document.getElementById('status').innerHTML);

	 }
	  },
	 fail:function(error){
 	var previous=document.getElementById("status").innerHTML;
 	document.getElementById("status").innerHTML="Error Creating new event in calendar</br>"+previous;
	 sessionStorage.setItem("status",document.getElementById('status').innerHTML);
	 }
	});
  }
}

function createCal(){
	 var filename=document.forms["createCal"]["fileNameC"].value;
	 var id=document.forms["createCal"]["IDC"].value;
	 var version=document.forms["createCal"]["VersionC"].value;
	 var userID=document.forms["createCal"]["usrIDE"].value;
	 var dtstart=document.forms["createCal"]["dtstart"].value;
	 var dtstamp=document.forms["createCal"]["dtstamp"].value;
	 var summary=document.forms["createCal"]["summary"].value;
	 var versionR=/^[0-9]+(.[0-9])*?$/;
	 var filenameR=/^[0-9a-zA-z]+.ics*$/;
	 var idR=/[^\s]{1,1000}$/;
	 var dtsR=/^[1-9]{1}\d{7}[T]\d{6}[Z]?$/;
	 var fileResp=filenameR.test(filename);
	 var verResp=versionR.test(version);
	 var idResp=idR.test(id);
	 var userResp=idR.test(userID);
	 var dtstartResp=dtsR.test(dtstart);
	 var dtstampResp=dtsR.test(dtstamp);
	 var overall=true;
	 if(verResp!=true){
	     overall=false;
	    var previous=document.getElementById("status").innerHTML;
	    document.getElementById("status").innerHTML="Invalid Version when creating calendar</br>"+previous;
	    sessionStorage.setItem("status",document.getElementById('status').innerHTML);

	 }
	 if(userResp!=true){
	   overall=false;
	    var previous=document.getElementById("status").innerHTML;
	    document.getElementById("status").innerHTML="Invalid UserID when creating calendar</br>"+previous;
	    sessionStorage.setItem("status",document.getElementById('status').innerHTML);

	 }
	 if(summary===""){
           overall=false;
	    var previous=document.getElementById("status").innerHTML;
	    document.getElementById("status").innerHTML="Invalid Summary when creating calendar</br>"+previous;
	    sessionStorage.setItem("status",document.getElementById('status').innerHTML);

	 }
	 if(dtstartResp!=true){
	   overall=false;
	    var previous=document.getElementById("status").innerHTML;
	    document.getElementById("status").innerHTML="Invalid Start Time when creating calendar</br>"+previous;
	    sessionStorage.setItem("status",document.getElementById('status').innerHTML);

	 } 
	if(dtstampResp!=true){
	  overall=false;
	    var previous=document.getElementById("status").innerHTML;
	    document.getElementById("status").innerHTML="Invalid Creation Time when creating calendar</br>"+previous;
	    sessionStorage.setItem("status",document.getElementById('status').innerHTML);

	}
	 if(fileResp!=true){
	  overall=false;
	    var previous=document.getElementById("status").innerHTML;
	    document.getElementById("status").innerHTML="Invalid Filename when creating calendar</br>"+previous;
	    sessionStorage.setItem("status",document.getElementById('status').innerHTML);

	 }
	 if(idResp!=true){
           overall=false;
	    var previous=document.getElementById("status").innerHTML;
	    document.getElementById("status").innerHTML="Invalid Calendar ID when creating calendar</br>"+previous;
	    sessionStorage.setItem("status",document.getElementById('status').innerHTML);

	 }
	 if(overall==true){
	 var obj={ 
		 "filename":filename,
		 "id":id,
		 "version":version,
		 "userId":userID,
		 "dtstart":dtstart,
		 "dtstamp":dtstamp,
		 "summary":summary
	 };
         }else{
		 obj={};
	}
	 var str=JSON.stringify(obj);
          
	if(str!=""){
		 $.ajax({
		  type:'get',
		  dataType:'json',
		  url:'/createCal',
		  data:obj,
		  success: function(data){
			if(data.response=="Success"){
			var previous=document.getElementById("status").innerHTML;
			  document.getElementById("status").innerHTML="Created a new Calender called "+ filename+".</br>"+previous;
			  sessionStorage.setItem("status",document.getElementById('status').innerHTML);
			document.getElementById('createCal').reset();
			document.location.reload();
			}else{
			var previous=document.getElementById("status").innerHTML;
	 	document.getElementById("status").innerHTML="Error Creating Calender called"+filename+".</br>"+previous;
		 sessionStorage.setItem("status",document.getElementById('status').innerHTML);

			}
		},
		 fail:function(error){
	 	var previous=document.getElementById("status").innerHTML;
	 	document.getElementById("status").innerHTML="Error Creating Calender</br>"+previous;
		 sessionStorage.setItem("status",document.getElementById('status').innerHTML);
		 }
		});
	}
 }

function evt(){
     $.ajax({
	  type:'get',
	  dataType:'json',
	  url:'/filenames',
	  success:function(data){
       $("#IcalE").empty();
       var i=0;
       for(i=0; i<data.filearr.length;i++){
	 (function(){
	  var newdrop=document.createElement("option");
	  newdrop.innerHTML=data.filearr[i].split('{')[0];
		newdrop.setAttribute('id','dropdownE');
		newdrop.setAttribute('value',data.filearr[i].split('{')[0]);
		newdrop.addEventListener('click',function(){createEvent(newdrop.value);},false);
		document.getElementById("IcalE").appendChild(newdrop);
	}());
        }
	},
	fail: function(error){
		console.log(error);
	}
	});
}
function loginData(){
	 var data=document.forms["login"]["database"].value;
	 var user=document.forms["login"]["usrName"].value;
	 var pass=document.forms["login"]["Password"].value;
	$.ajax({
	 type:'get',
	 dataType:'json',
	 url:'/login',
	 data:{username:user,
	       password:pass,
	       database:data},
	success:function(data){

	if(data.response=="connected"){
	 var previous=document.getElementById("status").innerHTML;
	 document.getElementById("status").innerHTML="Logged into Database</br>"+previous;
	 sessionStorage.setItem("status",document.getElementById('status').innerHTML);

	}else{
	var previous=document.getElementById("status").innerHTML;
 	document.getElementById("status").innerHTML="Error Logging into Database</br>"+previous;
	 sessionStorage.setItem("status",document.getElementById('status').innerHTML);
	}
	 sessionStorage.setItem("database",data.response);
	 document.getElementById("login").reset();
	 document.location.reload();
	},
	fail:function (error){
	}
	});
}

function showFile(){
	   $("#showFile").empty();
      $.ajax({
	  type:'get',
	  dataType:'json',
	  url:'/filenames',
	  success:function(data){
       var i=0;
       for(i=0; i<data.filearr.length;i++){
	(function(){
	  var newdrop=document.createElement("option");
	  newdrop.innerHTML=data.filearr[i].split('{')[0];
	  newdrop.setAttribute('id','dropdownI');
	  newdrop.setAttribute('value',data.filearr[i].split('{')[0]);
	  newdrop.addEventListener('click',function(){eventjson(newdrop.value);},false);
	  document.getElementById("showFile").appendChild(newdrop);
       }());
       }
	 },
	 fail:function(error){
		 console.log(error);
	 }
      });
}

function storeFiles(){
   var filedup=[];
   var rows=[];
   $.ajax({
        type: 'get',            //Request type
        dataType: 'json',       //Data type - we will use JSON for almost everything 
        url: '/filenames',   //The server endpoint we are connecting to
        success: function (data) {
		var z=0;
	  for(var i=0; i<data.filearr.length; i++){
		(function(){
	       var file=data.filearr[z].split('{')[0];
	       var rest=data.filearr[z].split(':');
	       var version=rest[1].split(',')[0];
	       var prod =rest[2].split('"')[1];
		z++;
	       var query ="INSERT INTO FILE (file_Name,version, prod_id) VALUES('"+file+"',"+version+",'"+prod+"')";
	  	$.ajax({
			type:'get',
			dataType:'json',
			url:'/addqueryfile',
			data:{string:query,
			      file:file
			},
			success:function(datat){
	if(!(file==datat.response)){
 	$.ajax({
  	type:'get',
 	 dataType:'json',
  	url:'/events',
  	data:{
		  file:file
   	},
   	success: function(datas){
		insertEvent(datas,file,datat);
	},
	fail:function(err){}
	});
	}
		},
	 fail:function(err){}
 });

	})();
	}

	},
	fail:function(err){
	var previous=document.getElementById("status").innerHTML;
 	document.getElementById("status").innerHTML="Error  adding files to Database</br>"+previous;
	 sessionStorage.setItem("status",document.getElementById('status').innerHTML);
	
	document.location.reload();
	}
   });
	
}
function insertEvent(datas,file,datat){
	parsed=JSON.parse(datas.response);
	  	for(var j=0; j<parsed.length;j++){
			const n=j;
			(function(){
			var start=parsed[n].startDT.date.slice(0,4)+'-';
			start=start+parsed[n].startDT.date.slice(4,6)+'-';
			start=start+parsed[n].startDT.date.slice(6)+" ";
			start=start+parsed[n].startDT.time.slice(0,2)+':';
			start=start+parsed[n].startDT.time.slice(2,4)+':';
			start=start+parsed[n].startDT.time.slice(4,6);
			var summary=parsed[n].summary;
			var locate=parsed[n].LOCATION;
			var organizer=parsed[n].ORGANIZER;
			var query="INSERT INTO EVENT (summary,start_time,location,organizer,cal_file) VALUES('"+summary+"','"+start+"','"+locate+"','"+organizer+"',"+datat.position[0].cal_id+")";
			$.ajax({
			type:'get',
			dataType:'json',
			url:'/addqueryevent',
			data:{string:query,
			},
			success:function(datae){
				insertAlarm(file,n+1,datae);	
			},
			fail:function(err){}
			});
		})();
		  }
}
function insertAlarm(file,n,datae){
	$.ajax({
				type:'get',
				dataType:'json',
				url:'/alarm',
				data:{file:file,
					id:n
				},
				success:function(dataa){
				  var alarms=JSON.parse(dataa.response);
   				for(var k=0; k<alarms.length; k++){
										
				const m=k;
				(function(){
	  			var trigger=alarms[m].Trigger;
   				var action=alarms[m].Action;
  				var query="INSERT INTO ALARM (action,`trigger`,event) VALUES('"+action+"','"+trigger+"',"+datae.row.insertId+")";
			$.ajax({
				type:'get',
				dataType:'json',
				url:'/addqueryalarm',
				data:{string:query},
				success:function(dataend){
				var previous=document.getElementById("status").innerHTML;
 	document.getElementById("status").innerHTML="Added files to Database</br>"+previous;
	 sessionStorage.setItem("status",document.getElementById('status').innerHTML);
	
	document.location.reload();

			},
				fail:function(err){
				
				console.log(err);}
			});
				})();
				}	
			},fail:function(err){
			console.log(err);
			}
			});

}
function clearData(){
$.ajax({
	type:'get',
	dataType:'json',
	url:'/deleteData',
	success:function(data){
	  var previous=document.getElementById("status").innerHTML;
	    document.getElementById("status").innerHTML="Cleared Data from Database</br>"+previous;
	    sessionStorage.setItem("status",document.getElementById('status').innerHTML);
	
	document.location.reload();
	},
	fail:function(err){}
});
}
function displayData(){
$.ajax({
	type:'get',
	dataType:'json',
	url:'/displaydata',
	success:function(data){
	var previous=document.getElementById("status").innerHTML;
	document.getElementById("status").innerHTML="Database has "+data.response[2].table_rows+" files, "+data.response[1].table_rows+" events, "+data.response[0].table_rows+" alarms</br>"+previous;
	sessionStorage.setItem("status",document.getElementById('status').innerHTML);
	document.location.reload();
	},
	fail:function(err){}
});
}
function query1(){
    $.ajax({
	type:'get',
	dataType:'json',
	url:'/displayeventdata',
	success:function(data){
	console.log(data.response);
	 $("#eventdata").empty();
    var table=document.getElementById("eventdata");
    var row=table.insertRow(table.rows.length);
    var id=row.insertCell(0);
    var start=row.insertCell(1);
    var org=row.insertCell(2);
    var loc=row.insertCell(3);
    var summary=row.insertCell(4);
    id.innerHTML='Event</br>No';
    start.innerHTML='Start time';
    org.innerHTML='Organizer';
    loc.innerHTML="Location";
    summary.innerHTML='Summary';

	for(var i=0; i<data.response.length; i++){
	 var row=table.insertRow(table.rows.length);
	       var id=row.insertCell(0);
	       var start=row.insertCell(1);
	       var org=row.insertCell(2);
	       var loc=row.insertCell(3);
	       var summary=row.insertCell(4);
	       id.innerHTML=data.response[i].event_id;;
	       start.innerHTML=data.response[i].start_time;
	       org.innerHTML=data.response[i].organizer;
		loc.innerHTML=data.response[i].location;
		summary=data.response[i].summary;
	}
	},
	fail:function(err){}
});

}
function query2(file){

 $.ajax({
	type:'get',
	dataType:'json',
	url:'/displayfileeventdata',
	data:{file:file},
	success:function(data){
	 $("#eventdata").empty();
    var table=document.getElementById("eventdata");
    var row=table.insertRow(table.rows.length);
    var id=row.insertCell(0);
    var start=row.insertCell(1);
    var org=row.insertCell(2);
    var loc=row.insertCell(3);
    var summary=row.insertCell(4);
    id.innerHTML='Event</br>No';
    start.innerHTML='Start time';
    org.innerHTML='Organizer';
    loc.innerHTML="Location";
    summary.innerHTML='Summary';

	for(var i=0; i<data.response.length; i++){
	 var row=table.insertRow(table.rows.length);
	       var id=row.insertCell(0);
	       var start=row.insertCell(1);
	       var org=row.insertCell(2);
	       var loc=row.insertCell(3);
	       var summary=row.insertCell(4);
	       id.innerHTML=data.response[i].event_id;
	       start.innerHTML=data.response[i].start_time;
	       org.innerHTML=data.response[i].organizer;
		loc.innerHTML=data.response[i].location;
		summary=data.response[i].summary;
	}
	},
	fail:function(err){}
});

}
function query3(){
 $.ajax({
	type:'get',
	dataType:'json',
	url:'/displayconflicteventdata',
	success:function(data){
	 $("#eventdata").empty();
    var table=document.getElementById("eventdata");
    var row=table.insertRow(table.rows.length);
    var id=row.insertCell(0);
    var start=row.insertCell(1);
    var org=row.insertCell(2);
    var loc=row.insertCell(3);
    var summary=row.insertCell(4);
    id.innerHTML='Event</br>No';
    start.innerHTML='Start time';
    org.innerHTML='Organizer';
    loc.innerHTML="Location";
    summary.innerHTML='Summary';

	for(var i=0; i<data.response.length; i++){
	 var row=table.insertRow(table.rows.length);
	       var id=row.insertCell(0);
	       var start=row.insertCell(1);
	       var org=row.insertCell(2);
	       var loc=row.insertCell(3);
	       var summary=row.insertCell(4);
	       id.innerHTML=data.response[i].event_id;
	       start.innerHTML=data.response[i].start_time;
	       org.innerHTML=data.response[i].organizer;
		loc.innerHTML=data.response[i].location;
		summary=data.response[i].summary;
	}
	},
	fail:function(err){}
});

}
function query4(){

 $.ajax({
	type:'get',
	dataType:'json',
	url:'/displayeventalarmdata',
	success:function(data){
	 $("#eventdata").empty();
    var table=document.getElementById("eventdata");
    var row=table.insertRow(table.rows.length);
    var id=row.insertCell(0);
    var start=row.insertCell(1);
    var org=row.insertCell(2);
    var loc=row.insertCell(3);
    var summary=row.insertCell(4);
    id.innerHTML='Event</br>No';
    start.innerHTML='Start time';
    org.innerHTML='Organizer';
    loc.innerHTML="Location";
    summary.innerHTML='Summary';

	for(var i=0; i<data.response.length; i++){
	 var row=table.insertRow(table.rows.length);
	       var id=row.insertCell(0);
	       var start=row.insertCell(1);
	       var org=row.insertCell(2);
	       var loc=row.insertCell(3);
	       var summary=row.insertCell(4);
	       id.innerHTML=data.response[i].event_id;
	       start.innerHTML=data.response[i].start_time;
	       org.innerHTML=data.response[i].organizer;
		loc.innerHTML=data.response[i].location;
		summary=data.response[i].summary;
	}
	},
	fail:function(err){}
});

}
function query5(){
 $.ajax({
	type:'get',
	dataType:'json',
	url:'/displayalarmObidata',
	success:function(data){
		 $("#eventdata").empty();
    var table=document.getElementById("eventdata");
    var row=table.insertRow(table.rows.length);
    var id=row.insertCell(0);
    var alarm=row.insertCell(1);
    var trigger=row.insertCell(2);
	id.innerHTML="ALARM</br>No";
	alarm.innerHTML="ACTION";
	trigger.innerHTML="TRIGGER";
for(var i=0; i<data.response.length; i++){
	 var row=table.insertRow(table.rows.length);
	       var id=row.insertCell(0);
	       var alarm=row.insertCell(1);
	       var trigger=row.insertCell(2);
	       id.innerHTML=data.response[i].alarm_id;
	       alarm.innerHTML=data.response[i].action;
	       trigger.innerHTML=data.response[i].trigger;
	}
	},
	fail:function(err){}
});

}
function query6(){
 $.ajax({
	type:'get',
	dataType:'json',
	url:'/displayfilealarmdata',
	success:function(data){
		 $("#eventdata").empty();
    var table=document.getElementById("eventdata");
    var row=table.insertRow(table.rows.length);
    var id=row.insertCell(0);
    var file=row.insertCell(1);
    var ver=row.insertCell(2);
	id.innerHTML="Calendar</br>No";
	file.innerHTML="File Name";
	ver.innerHTML="Version";
for(var i=0; i<data.response.length; i++){
	 var row=table.insertRow(table.rows.length);
	       var id=row.insertCell(0);
	       var file=row.insertCell(1);
	       var ver=row.insertCell(2);
	       id.innerHTML=data.response[i].cal_id;
	       file.innerHTML=data.response[i].file_Name;
	       ver.innerHTML=data.response[i].version;
	}
	},
	 fail:function(err){}
});
}

function query2d(){
   $("#query2d").empty();

 $.ajax({
	  type:'get',
	  dataType:'json',
	  url:'/filenames',
	  success:function(data){
       var i=0;
       for(i=0; i<data.filearr.length;i++){
	(function(){
	  var newdrop=document.createElement("option");
	  newdrop.innerHTML=data.filearr[i].split('{')[0];
	  newdrop.setAttribute('id','dropdownk');
	  newdrop.setAttribute('value',data.filearr[i].split('{')[0]);
	  newdrop.addEventListener('click',function(){query2(newdrop.value);},false);
	  document.getElementById("query2d").appendChild(newdrop);
       }());
       }
	 },
	 fail:function(error){
		 console.log(error);
	 }
      });

}
